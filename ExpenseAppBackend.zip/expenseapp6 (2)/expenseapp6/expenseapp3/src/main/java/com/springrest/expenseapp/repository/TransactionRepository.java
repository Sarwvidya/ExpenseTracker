package com.springrest.expenseapp.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.entity.Transaction;


@Repository
public interface TransactionRepository extends JpaRepository<Transaction,Long> {
	List<Transaction> findByMonthWallet(MonthWallet monthWallet);
	
	@Query("SELECT SUM(CASE WHEN type = 1 and monthWallet.id=?1 THEN amount ELSE 0 END) - SUM(CASE WHEN type = 2 and monthWallet.id=?1 THEN amount ELSE 0 END) AS difference FROM Transaction")
	Double getValueFromTable(long id);
    
    
    @Query("SELECT SUM(CASE WHEN type = 2 and monthWallet.id=?1 THEN amount ELSE 0 END) AS tp2 FROM Transaction")
	Double getexpenses(long id);
    
    @Query("SELECT SUM(CASE WHEN type = 1 and monthWallet.id=?1 THEN amount ELSE 0 END) AS tp2 FROM Transaction")
   	Double getsalary(long id);
}
