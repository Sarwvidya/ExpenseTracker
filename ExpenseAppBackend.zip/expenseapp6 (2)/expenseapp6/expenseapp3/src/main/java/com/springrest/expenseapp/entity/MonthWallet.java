package com.springrest.expenseapp.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="monthwallet")
public class MonthWallet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank(message = "Name cannot be empty")
	@Size(min = 2, max = 64)
	private String name;	
	
	@Size(min = 2, max = 20)
	private String accountNumber;
	
	@Size(max = 100)
	private String description;
	
	@Min(1)
	@Max(3)
	private Integer priority;
	
	private Double monthBalance;
	
	private Double monthExpense;
	
	private Double monthSalary;

	private int user_id;
	
	@SuppressWarnings({ "removal" })
	@PrePersist
	public void setBalance(){ 
		this.monthBalance = new Double(0);
		this.monthExpense = new Double(0);
		this.monthSalary = new Double(0);
	}

	public Double getMonthExpense() {
		return monthExpense;
	}

	public void setMonthExpense(Double monthExpense) {
		this.monthExpense = monthExpense;
	}

	public Double getMonthSalary() {
		return monthSalary;
	}

	public void setMonthSalary(Double monthSalary) {
		this.monthSalary = monthSalary;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Double getMonthBalance() {
		return monthBalance;
	}

	public void setMonthBalance(Double monthBalance) {
//		if(type == 1) {
//			this.monthBalance += monthBalance;
//		}
//		else if(type == 2) {
//			this.monthBalance -= monthBalance;
//		}
		this.monthBalance = monthBalance;
	}
	
	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public MonthWallet(Long id, @NotBlank(message = "Name cannot be empty") @Size(min = 2, max = 64) String name,
			@Size(min = 2, max = 20) String accountNumber, @Size(max = 100) String description,
			@Min(1) @Max(3) Integer priority, Double monthBalance) {
		super();
		this.id = id;
		this.name = name;
		this.accountNumber = accountNumber;
		this.description = description;
		this.priority = priority;
		this.monthBalance = monthBalance;
	}

	public MonthWallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "MonthWallet [id=" + id + ", name=" + name + ", accountNumber=" + accountNumber + ", description="
				+ description + ", priority=" + priority + ", monthBalance=" + monthBalance + "]";
	}
	
	

}

