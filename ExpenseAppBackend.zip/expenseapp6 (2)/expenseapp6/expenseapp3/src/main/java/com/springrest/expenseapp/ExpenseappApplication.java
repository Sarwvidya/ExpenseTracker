package com.springrest.expenseapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseappApplication {

	public
	static void main(String[] args) {
		SpringApplication.run(ExpenseappApplication.class, args);
	}
}
