package com.springrest.expenseapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.entity.Transaction;
import com.springrest.expenseapp.exception.MonthWalletException;
import com.springrest.expenseapp.repository.MonthWalletRepository;
import com.springrest.expenseapp.repository.TransactionRepository;

import java.util.List;
import java.util.Optional;
@Service
public class TransactionService {
	
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private MonthWalletRepository monthWalletRepo;
    
    public List<Transaction> getAll(Long walletId){
        Optional<MonthWallet> monthWallet = monthWalletRepo.findById(walletId);
        if(monthWallet.isPresent()){
            return transactionRepository.findByMonthWallet(monthWallet.get());
        }
        return null;
    }
    public Transaction getById(Long wallet_id,Long id){
        Optional<MonthWallet> monthWallet = monthWalletRepo.findById(wallet_id);
        if(monthWallet.isPresent()) {
            Optional<Transaction> transaction = transactionRepository.findById(id);
            if (transaction.isPresent()) {
                return transaction.get();
            }
        }
        throw new MonthWalletException("Transaction with "+id+" does not exists!");
    }

	
	  public Transaction createOrUpdate(Long walletId, Transaction transaction){
	  Optional<MonthWallet> monthWallet = monthWalletRepo.findById(walletId);
	  if(monthWallet.isPresent()){
	  
	  transaction.setMonthWallet(monthWallet.get());
	  transactionRepository.save(transaction);
	  monthWallet.get().setMonthBalance(transactionRepository.getValueFromTable((long)1));
	  return transaction; } return null; }
	 
    public boolean delete(Long wallet_id,Long id){
        Optional<MonthWallet> monthWallet = monthWalletRepo.findById(wallet_id);
        if(monthWallet.isPresent()) {
            Optional<Transaction> transaction = transactionRepository.findById(id);
            if (transaction.isPresent()) {
                transactionRepository.delete(transaction.get());
                return true;
            }
        }
        throw new MonthWalletException("Transaction with "+id+" does not exists!");
    }
}