package com.springrest.expenseapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.entity.Transaction;
@Repository
public interface MonthWalletRepository extends JpaRepository<MonthWallet, Long> {
	
	List<MonthWallet> findAllByOrderByPriority();

}


