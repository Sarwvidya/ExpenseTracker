package com.springrest.expenseapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.expenseapp.entity.User;
import com.springrest.expenseapp.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UserController {

	@Autowired
	private final UserService userService;

	@Autowired
	public UserController(UserService userService) {
		this.userService = userService;
	}

	@GetMapping("/get")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/get/{id}")
	public User getUserById(@PathVariable("id") long id) {
		return userService.getUserById(id);
	}

	@PostMapping("/post")
	public User createUser(@RequestBody User user) {
		return userService.createUser(user);
	}

	@PutMapping("/put/{id}")
	public User updateUser(@PathVariable("id") long id, @RequestBody User user) {
		return userService.updateUser(id, user);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteUser(@PathVariable("id") long id) {
		userService.deleteUser(id);
	}

	@GetMapping("/login")
	public String loginCustomerPage(){
		return "LoginCustomer";
	}

	@GetMapping("/register")
	public String registerCustomerPage(){
		return "RegisterCustomer";
	}

	@PostMapping("/login")
	public User login(@RequestBody User user ) {
		User user2 = userService.login(user.getEmail(), user.getPassword());
		return user2;
	}
	
	@RequestMapping(value = {"/logout"}, method = RequestMethod.POST)
    public String logoutDo(HttpServletRequest request,HttpServletResponse response)
    {
        return "redirect:/login";
    }

}
