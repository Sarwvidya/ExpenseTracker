package com.springrest.expenseapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.entity.Transaction;
import com.springrest.expenseapp.exception.MonthWalletException;
import com.springrest.expenseapp.repository.MonthWalletRepository;
import com.springrest.expenseapp.repository.TransactionRepository;

@Service
public class MonthWalletService {
	
	@Autowired
	private MonthWalletRepository monthWalletRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	 public List<MonthWallet> getAll() { return
	 monthWalletRepository.findAllByOrderByPriority(); }
	
	public MonthWallet getById(Long id) {
		Optional<MonthWallet> monthWallet =  monthWalletRepository.findById(id);
		if(monthWallet.isPresent()) {
			return monthWallet.get();
		}
		throw new MonthWalletException("Wallet with "+id+" does not exists!");
	}
	
	public MonthWallet CreateorUpdate(MonthWallet monthWallet) {
		if(monthWallet.getId() == null) {
			monthWalletRepository.save(monthWallet);
		}else{
			monthWalletRepository.save(monthWallet);
		}
		
		return monthWallet;
	}
	
	public boolean delete(Long id) {
		Optional<MonthWallet> monthWallet =  monthWalletRepository.findById(id);
		List<Transaction> trans = transactionRepository.findByMonthWallet(monthWallet.get());
		if(monthWallet.isPresent()) {
			trans.forEach((transaction) -> transactionRepository.delete(transaction));
			monthWalletRepository.delete(monthWallet.get());
			return true;
		}
		throw new MonthWalletException("Wallet with "+id+" does not exists!");
	}
	
}
