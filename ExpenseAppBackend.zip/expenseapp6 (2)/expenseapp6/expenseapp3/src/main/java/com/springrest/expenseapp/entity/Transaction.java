package com.springrest.expenseapp.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Entity
public class Transaction {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
    @Min(1)
    @NotNull(message = "amount cann't be null")
    private Double amount;
    
    private String description
    ;
    @Min(1)
    @Max(2)
    private int type;//1 for withdraw, 2 deposite
    
    private String transactionDate;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "wallet_id",nullable = false)
    @JsonIgnore
    private MonthWallet monthWallet;

    public void setTransactionDate(){ 
    	Date date = new Date();
    	this.transactionDate = date.toString(); 
    	System.out.println(this.transactionDate);
    	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public MonthWallet getMonthWallet() {
		return monthWallet;
	}

	public void setMonthWallet(MonthWallet monthWallet) {
		this.monthWallet = monthWallet;
	}
    
}

