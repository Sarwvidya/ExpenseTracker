package com.springrest.expenseapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.service.MonthWalletService;
import com.springrest.expenseapp.service.ValidationErrorService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/monthwallet")
@CrossOrigin
public class MonthWalletController {

	@Autowired
	private  MonthWalletService monthWalletService;

	@Autowired
	private ValidationErrorService validationErrorService;

	@GetMapping("/get")
	public ResponseEntity<?> getAll(){
		return new ResponseEntity<>(monthWalletService.getAll(), HttpStatus.OK);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<?> getById(@PathVariable Long id){
		return new ResponseEntity<>(monthWalletService.getById(id), HttpStatus.OK);
	}

	@PostMapping("/post")
	public ResponseEntity<?> create(@Valid @RequestBody MonthWallet monthWallet, BindingResult result){

		ResponseEntity<?> errors = validationErrorService.validate(result);
		if(errors != null) return errors;

		MonthWallet walletSaved  = monthWalletService.CreateorUpdate(monthWallet);
		return new ResponseEntity<MonthWallet>(walletSaved, HttpStatus.CREATED);
	}public MonthWalletController() {
	}

	@PutMapping("/put/{id}")
	public ResponseEntity<?> update(@PathVariable Long id, @Valid @RequestBody MonthWallet monthWallet, BindingResult result){

		ResponseEntity<?> errors = validationErrorService.validate(result);
		if(errors != null) return errors;
		monthWallet.setId(id);
		MonthWallet walletSaved  = monthWalletService.CreateorUpdate(monthWallet);
		return new ResponseEntity<MonthWallet>(walletSaved, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id){
		monthWalletService.delete(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
