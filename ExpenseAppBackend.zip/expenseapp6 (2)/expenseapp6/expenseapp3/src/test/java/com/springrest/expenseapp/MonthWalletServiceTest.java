package com.springrest.expenseapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.exception.MonthWalletException;
import com.springrest.expenseapp.repository.MonthWalletRepository;
import com.springrest.expenseapp.service.MonthWalletService;

class MonthWalletServiceTest {

	@Mock
	private MonthWalletRepository monthWalletRepository;

	@InjectMocks
	private MonthWalletService monthWalletService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetAll() {

		MonthWallet wallet1 = new MonthWallet();
		MonthWallet wallet2 = new MonthWallet();
		List<MonthWallet> walletList = new ArrayList<>();
		walletList.add(wallet1);
		walletList.add(wallet2);

		when(monthWalletRepository.findAllByOrderByPriority()).thenReturn(walletList);

		List<MonthWallet> result = monthWalletService.getAll();

		assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals(wallet1, result.get(0));
		assertEquals(wallet2, result.get(1));
	}

	@Test
	void testGetById_ExistingId() {
		Long id = 1L;
		MonthWallet wallet = new MonthWallet();

		when(monthWalletRepository.findById(id)).thenReturn(Optional.of(wallet));

		MonthWallet result = monthWalletService.getById(id);

		assertNotNull(result);
		assertEquals(wallet, result);
	}

	@Test
	void testGetById_NonExistingId() {
		Long id = 100L;

		when(monthWalletRepository.findById(id)).thenReturn(Optional.empty());

		assertThrows(MonthWalletException.class, () -> monthWalletService.getById(id));
	}

	@Test
	void testCreateOrUpdate_ExistingMonthWallet() {
		MonthWallet wallet = new MonthWallet();

		when(monthWalletRepository.save(wallet)).thenReturn(wallet);

		MonthWallet result = monthWalletService.CreateorUpdate(wallet);

		assertNotNull(result);
		assertEquals(wallet, result);
		verify(monthWalletRepository, times(1)).save(wallet);
	}

	@Test
	void testDelete_ExistingId() {
		Long id = 1L;
		MonthWallet wallet = new MonthWallet();

		when(monthWalletRepository.findById(id)).thenReturn(Optional.of(wallet));

		boolean result = monthWalletService.delete(id);

		assertTrue(result);
		verify(monthWalletRepository, times(1)).delete(wallet);
	}

	@Test
	void testDelete_NonExistingId() {
		Long id = 100L;

		when(monthWalletRepository.findById(id)).thenReturn(Optional.empty());

		assertThrows(MonthWalletException.class, () -> monthWalletService.delete(id));
	}

}
