package com.springrest.expenseapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.springrest.expenseapp.entity.MonthWallet;
import com.springrest.expenseapp.entity.Transaction;
import com.springrest.expenseapp.exception.MonthWalletException;
import com.springrest.expenseapp.repository.MonthWalletRepository;
import com.springrest.expenseapp.repository.TransactionRepository;
import com.springrest.expenseapp.service.TransactionService;

class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;
    
    @Mock
    private MonthWalletRepository monthWalletRepository;

    @InjectMocks
    private TransactionService transactionService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAll_ValidWalletId() {
        Long walletId = 1L;
        MonthWallet monthWallet = new MonthWallet();
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction());
        transactions.add(new Transaction());

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.of(monthWallet));
        when(transactionRepository.findByMonthWallet(monthWallet)).thenReturn(transactions);

        List<Transaction> result = transactionService.getAll(walletId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(transactions, result);
    }

    @Test
    void testGetAll_InvalidWalletId() {
        Long walletId = 100L;

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.empty());

        List<Transaction> result = transactionService.getAll(walletId);

        assertNull(result);
    }

    @Test
    void testGetById_ExistingIds() {
        Long walletId = 1L;
        Long transactionId = 1L;
        MonthWallet monthWallet = new MonthWallet();
        Transaction transaction = new Transaction();

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.of(monthWallet));
        when(transactionRepository.findById(transactionId)).thenReturn(Optional.of(transaction));

        Transaction result = transactionService.getById(walletId, transactionId);

        assertNotNull(result);
        assertEquals(transaction, result);
    }

    @Test
    void testGetById_NonExistingTransactionId() {
        Long walletId = 1L;
        Long transactionId = 100L;
        MonthWallet monthWallet = new MonthWallet();

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.of(monthWallet));
        when(transactionRepository.findById(transactionId)).thenReturn(Optional.empty());

        assertThrows(MonthWalletException.class, () -> transactionService.getById(walletId, transactionId));
    }

    @Test
    void testGetById_NonExistingWalletId() {
        Long walletId = 100L;
        Long transactionId = 1L;

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.empty());

        assertThrows(MonthWalletException.class, () -> transactionService.getById(walletId, transactionId));
    }

    @Test
    void testCreateOrUpdate_InvalidWalletId() {
        Long walletId = 100L;
        Transaction transaction = new Transaction();

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.empty());

        Transaction result = transactionService.createOrUpdate(walletId, transaction);

        assertNull(result);
    }

    @Test
    void testDelete_ExistingIds() {
        Long walletId = 1L;
        Long transactionId = 1L;
        MonthWallet monthWallet = new MonthWallet();
        Transaction transaction = new Transaction();

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.of(monthWallet));
        when(transactionRepository.findById(transactionId)).thenReturn(Optional.of(transaction));

        boolean result = transactionService.delete(walletId, transactionId);

        assertTrue(result);
        verify(transactionRepository, times(1)).delete(transaction);
    }

    @Test
    void testDelete_NonExistingTransactionId() {
        Long walletId = 1L;
        Long transactionId = 100L;
        MonthWallet monthWallet = new MonthWallet();

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.of(monthWallet));
        when(transactionRepository.findById(transactionId)).thenReturn(Optional.empty());

        assertThrows(MonthWalletException.class, () -> transactionService.delete(walletId, transactionId));
    }

    @Test
    void testDelete_NonExistingWalletId() {
        Long walletId = 100L;
        Long transactionId = 1L;

        when(monthWalletRepository.findById(walletId)).thenReturn(Optional.empty());

        assertThrows(MonthWalletException.class, () -> transactionService.delete(walletId, transactionId));
    }
}
