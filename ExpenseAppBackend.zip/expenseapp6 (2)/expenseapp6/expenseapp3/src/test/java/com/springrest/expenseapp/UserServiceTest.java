package com.springrest.expenseapp;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.springrest.expenseapp.entity.User;
import com.springrest.expenseapp.repository.UserRepository;
import com.springrest.expenseapp.service.UserService;

class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllUsers() {
        List<User> users = new ArrayList<>();
        users.add(new User());
        users.add(new User());

        when(userRepository.findAll()).thenReturn(users);

        List<User> result = userService.getAllUsers();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(users, result);
    }

    @Test
    void testGetUserById_ExistingId() {
        Long id = 1L;
        User user = new User();

        when(userRepository.findById(id)).thenReturn(Optional.of(user));

        User result = userService.getUserById(id);

        assertNotNull(result);
        assertEquals(user, result);
    }

    @Test
    void testGetUserById_NonExistingId() {
        Long id = 100L;

        when(userRepository.findById(id)).thenReturn(Optional.empty());

        User result = userService.getUserById(id);

        assertNull(result);
    }

    @Test
    void testUpdateUser_ExistingId() {
        Long id = 1L;
        User user = new User();
        User updatedUser = new User();

        when(userRepository.save(user)).thenReturn(updatedUser);

        User result = userService.updateUser(id, user);

        assertNotNull(result);
        assertEquals(updatedUser, result);
    }

    @Test
    void testUpdateUser_NonExistingId() {
        Long id = 100L;
        User user = new User();

        User result = userService.updateUser(id, user);

        assertNull(result);
    }

    @Test
    void testDeleteUser_ExistingId() {
        Long id = 1L;

        assertDoesNotThrow(() -> userService.deleteUser(id));

        verify(userRepository, times(1)).deleteById(id);
    }

    @Test
    void testLogin_ValidCredentials() {
        String email = "john@example.com";
        String password = "password";
        User user = new User();

        when(userRepository.findByEmailAndPassword(email, password)).thenReturn(user);

        User result = userService.login(email, password);

        assertNotNull(result);
        assertEquals(user, result);
    }

    @Test
    void testLogin_InvalidCredentials() {
        String email = "john@example.com";
        String password = "password";

        when(userRepository.findByEmailAndPassword(email, password)).thenReturn(null);

        User result = userService.login(email, password);

        assertNull(result);
    }
}
